<?php

namespace Modules\Staff\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    // Add any shared logic for your module controllers here
}
