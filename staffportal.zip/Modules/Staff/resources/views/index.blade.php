@extends('staff::layouts.master')

@section('content')
    <div class="container">
        <h1>Staff Management</h1>
        <a href="{{ route('staff.create') }}" class="btn btn-primary mb-3">Add New Staff</a>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Email</th>
                    <th>Photo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($employees as $employee)
                    <tr>
                        <td>{{ $employee->name }}</td>
                        <td>{{ $employee->phone_number }}</td>
                        <td>{{ $employee->email }}</td>
                        <td>
                            @if ($employee->profile_image)
                                <img src="{{ asset('storage/' . $employee->profile_image) }}" alt="Profile Image"
                                    width="100">
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('staff.show', $employee->id) }}" class="btn btn-sm btn-primary">View</a>
                            <a href="{{ route('staff.edit', $employee->id) }}" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('staff.destroy', $employee->id) }}" method="POST"
                                style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
