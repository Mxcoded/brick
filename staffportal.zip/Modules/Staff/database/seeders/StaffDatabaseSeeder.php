<?php

namespace Modules\Staff\Database\Seeders;

use Illuminate\Database\Seeder;

class StaffDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
