


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Employee Details</h1>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="card-title mb-0"><?php echo e($employee->name); ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Profile Image -->
                <div class="col-md-4 text-center">
                    <?php if($employee->profile_image): ?>
                        <img src="<?php echo e(asset('storage/' . $employee->profile_image)); ?>" alt="Profile Image" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px;">
                    <?php else: ?>
                        <div class="bg-light rounded-circle d-flex align-items-center justify-content-center mb-3" style="width: 150px; height: 150px;">
                            <span class="text-muted">No Image</span>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Employee Details -->
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Place of Birth:</strong> <?php echo e($employee->place_of_birth); ?></p>
                            <p><strong>State of Origin:</strong> <?php echo e($employee->state_of_origin); ?></p>
                            <p><strong>LGA:</strong> <?php echo e($employee->lga); ?></p>
                            <p><strong>Nationality:</strong> <?php echo e($employee->nationality); ?></p>
                            <p><strong>Gender:</strong> <?php echo e($employee->gender); ?></p>
                            <p><strong>Date of Birth:</strong> <?php echo e($employee->date_of_birth); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Marital Status:</strong> <?php echo e($employee->marital_status); ?></p>
                            <p><strong>Blood Group:</strong> <?php echo e($employee->blood_group); ?></p>
                            <p><strong>Genotype:</strong> <?php echo e($employee->genotype); ?></p>
                            <p><strong>Phone Number:</strong> <?php echo e($employee->phone_number); ?></p>
                            <p><strong>Residential Address:</strong> <?php echo e($employee->residential_address); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Next of Kin and ICE Contact -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <h5>Next of Kin</h5>
                    <p><strong>Name:</strong> <?php echo e($employee->next_of_kin_name); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($employee->next_of_kin_phone); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>In Case of Emergency (ICE) Contact</h5>
                    <p><strong>Name:</strong> <?php echo e($employee->ice_contact_name); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($employee->ice_contact_phone); ?></p>
                </div>
            </div>

            <!-- CV Section -->
            <div class="row mt-4">
                <div class="col-md-12">
                    <h5>CV</h5>
                    <?php if($employee->cv_path): ?>
                        <a href="<?php echo e(asset('storage/' . $employee->cv_path)); ?>" target="_blank" class="btn btn-primary">
                            <i class="fas fa-download"></i> Download CV
                        </a>
                    <?php else: ?>
                        <p class="text-muted">No CV uploaded.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Employment History Section -->
    <div class="card mt-4">
        <div class="card-header bg-secondary text-white">
            <h5 class="card-title mb-0">Employment History</h5>
        </div>
        <div class="card-body">
            <?php if($employee->employmentHistories->isEmpty()): ?>
                <p class="text-muted">No employment history available.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Employer Name</th>
                                <th>Employer Contact</th>
                                <th>Position Held</th>
                                <th>Duration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->employmentHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($history->employer_name); ?></td>
                                    <td><?php echo e($history->employer_contact); ?></td>
                                    <td><?php echo e($history->position_held); ?></td>
                                    <td><?php echo e($history->duration); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Educational Background Section -->
    <div class="card mt-4">
        <div class="card-header bg-secondary text-white">
            <h5 class="card-title mb-0">Educational Background</h5>
        </div>
        <div class="card-body">
            <?php if($employee->educationalBackgrounds->isEmpty()): ?>
                <p class="text-muted">No educational background available.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>School Name</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Qualification</th>
                                <th>Certificate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employee->educationalBackgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($education->school_name); ?></td>
                                    <td><?php echo e($education->start_date); ?></td>
                                    <td><?php echo e($education->end_date); ?></td>
                                    <td><?php echo e($education->qualification); ?></td>
                                    <td>
                                        <?php if($education->certificate_path): ?>
                                            <a href="<?php echo e(asset('storage/' . $education->certificate_path)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                                <i class="fas fa-download"></i> Download
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">No certificate</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Back Button -->
    <div class="mt-4">
        <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Staff List
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DanielX\Documents\Brickspoint Asokoro\PROJECTS\Website\staffportal\Modules/Staff\resources/views/show.blade.php ENDPATH**/ ?>