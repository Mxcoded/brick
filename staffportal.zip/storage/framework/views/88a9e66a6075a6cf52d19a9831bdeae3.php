

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Complete Your Registration</h1>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('staff.complete-registration.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="staff_code">Staff Code</label>
            <input type="text" name="staff_code" id="staff_code" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DanielX\Documents\Brickspoint Asokoro\PROJECTS\Website\staffportal\Modules/Staff\resources/views/complete-registration.blade.php ENDPATH**/ ?>