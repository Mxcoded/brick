

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Staff</h1>
     <!-- Back Button -->
    <div class="mt-4">
        <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Staff List
        </a>
    </div>
    <form action="<?php echo e(route('staff.update', $employee->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Personal Details Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">Personal Details</h5>
            </div>
            <div class="card-body">
                <?php echo $__env->make('staff::partials.personal_details_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

       <!-- Employment History Section -->
<div class="card mb-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="card-title mb-0">Employment History</h5>
    </div>
    <div class="card-body">
        <div id="employment-history-container">
            <?php $__currentLoopData = $employee->employmentHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('staff::partials.employment_history_form', [
                    'index' => $index,
                    'history' => $history
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="button" id="add-employment-history" class="btn btn-sm btn-success">
            <i class="fas fa-plus"></i> Add Another Employment History
        </button>
    </div>
</div>

<!-- Educational Background Section -->
<div class="card mb-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="card-title mb-0">Educational Background</h5>
    </div>
    <div class="card-body">
        <div id="educational-background-container">
            <?php $__currentLoopData = $employee->educationalBackgrounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('staff::partials.educational_background_form', [
                    'index' => $index,
                    'education' => $education
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="button" id="add-educational-background" class="btn btn-sm btn-success">
            <i class="fas fa-plus"></i> Add Another Educational Background
        </button>
    </div>
</div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<!-- JavaScript for Dynamic Form Fields -->
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/staff/dynamic-forms.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DanielX\Documents\Brickspoint Asokoro\PROJECTS\Website\staffportal\Modules/Staff\resources/views/edit.blade.php ENDPATH**/ ?>