

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add New Staff</h1>
    <!-- Back Button -->
    <div class="mt-4">
        <a href="<?php echo e(route('staff.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Staff List
        </a>
    </div>
    <form action="<?php echo e(route('staff.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <!-- Personal Details Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0">Personal Details</h5>
            </div>
            <div class="card-body">
                <?php echo $__env->make('staff::partials.personal_details_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

<!-- Employment History Section -->
<div class="card mb-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="card-title mb-0">Employment History (Optional)</h5>
    </div>
    <div class="card-body">
        <div id="employment-history-container">
            <?php echo $__env->make('staff::partials.employment_history_form', ['index' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <button type="button" id="add-employment-history" class="btn btn-sm btn-success">
            <i class="fas fa-plus"></i> Add Another Employment History
        </button>
    </div>
</div>

<!-- Educational Background Section -->
<div class="card mb-4">
    <div class="card-header bg-secondary text-white">
        <h5 class="card-title mb-0">Educational Background (Optional)</h5>
    </div>
    <div class="card-body">
        <div id="educational-background-container">
            <?php echo $__env->make('staff::partials.educational_background_form', ['index' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <button type="button" id="add-educational-background" class="btn btn-sm btn-success">
            <i class="fas fa-plus"></i> Add Another Educational Background
        </button>
    </div>
</div>
        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/staff/dynamic-forms.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DanielX\Documents\Brickspoint Asokoro\PROJECTS\Website\staffportal\Modules/Staff\resources/views/create.blade.php ENDPATH**/ ?>