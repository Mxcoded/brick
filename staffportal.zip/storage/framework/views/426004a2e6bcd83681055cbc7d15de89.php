<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Staff Management</h1>
        <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-primary mb-3">Add New Staff</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Email</th>
                    <th>Photo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($employee->name); ?></td>
                        <td><?php echo e($employee->phone_number); ?></td>
                        <td><?php echo e($employee->email); ?></td>
                        <td>
                            <?php if($employee->profile_image): ?>
                                <img src="<?php echo e(asset('storage/' . $employee->profile_image)); ?>" alt="Profile Image"
                                    width="100">
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('staff.show', $employee->id)); ?>" class="btn btn-sm btn-primary">View</a>
                            <a href="<?php echo e(route('staff.edit', $employee->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('staff.destroy', $employee->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                    onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DanielX\Documents\Brickspoint Asokoro\PROJECTS\Website\staffportal\Modules/Staff\resources/views/index.blade.php ENDPATH**/ ?>