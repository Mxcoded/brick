<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Staff\\Providers\\StaffServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Staff\\Providers\\StaffServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);